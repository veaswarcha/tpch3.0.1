insert into store_sales (select * from ssv);
rollback;
